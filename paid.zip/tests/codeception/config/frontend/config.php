<?php
/**
 * Application configuration for all frontend test types
 */
return [];
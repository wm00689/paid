<!--产品展示-->
<div id="product">
    <div id="pro">
        <div class="dz_xiazai">
            <p class="style1">简单的操作界面</p>
            <p class="style2"><span>简单易用</span>快速输出</p>
            <a href="http://pan.baidu.com/share/link?shareid=1702916987&uk=2986394198&qq-pf-to=pcqq.c2c" class="style3">立即下载</a>
        </div>
        <div class="dz_img"><img src="/images/gx1.jpg" /></div>
        <div class="clear"></div>
        <div class="dz_img2"><img src="/images/gx2.jpg" /></div>
    </div>
</div>
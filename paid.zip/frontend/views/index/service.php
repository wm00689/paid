<!--产品展示流程-->
<div id="product">
    <div id="pro">

        <img src="/images/lc.jpg" />
    </div>
</div>
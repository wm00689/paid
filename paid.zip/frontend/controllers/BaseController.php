<?php
/**
 * Created by PhpStorm.
 * User: wm
 * Date: 2015/3/18
 * Time: 7:39
 */

namespace frontend\controllers;


use yii\web\Controller;

class BaseController extends Controller{

    public $layout = 'pintuer';

}
<?php
/**
 * Created by PhpStorm.
 * User: wm
 * Date: 2015/3/23
 * Time: 13:30
 */

namespace frontend\controllers;


use yii\web\Controller;

class FrontController extends Controller{
    public $layout = 'pages';
} 
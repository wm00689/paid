<?php
use yii\helpers\Html;
use yii\bootstrap\ActiveForm;

/* @var $this yii\web\View */
/* @var $form yii\bootstrap\ActiveForm */
/* @var $model \common\models\LoginForm */

$this->title = '设置';
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="site-login">


    <div class="row">


    </div>
</div>

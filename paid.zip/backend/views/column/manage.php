<?php
/**
 * Created by PhpStorm.
 * User: wm
 * Date: 2015/3/24
 * Time: 14:37
 */
?>
<?= $for ?>
<?= $id ?>
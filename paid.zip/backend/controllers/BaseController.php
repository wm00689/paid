<?php
/**
 * Created by PhpStorm.
 * User: wm
 * Date: 15-3-4
 * Time: 上午8:18
 */

namespace backend\controllers;


use yii\web\Controller;

class BaseController extends Controller{

    public $layout = 'admin';

}